// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
  //全局变量
  globalData: {
    userInfo: null,
    tempertaure: 0,
    illumination: 0,
    airhumidty: 0,
    soilhumidty: 0,
    residue_water: 0
  },
})



