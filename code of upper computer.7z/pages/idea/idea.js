
var util = require( "../.././utils/util.js" );
//在page页面引入app，同时声明变量，获得所需要的全局变量

var start_time_set = '00:00';
var end_time_set = '00:00';
var start_time_value = '';

Page({
  /**
   * 页面的初始数据
   */
  //传到前端的数据
  data: {
    master_value: false,
    threshold_value: false,
    time_value: false,
    start_time: start_time_set,
    end_time: end_time_set,
  },

  //总开关开
  RGB_master_butten_open:function(){
    let data={
    "datastreams": [  
     {"id": "RGB_master","datapoints":[{"value": 1}]},
      //led是数据流的名称，value是要传上去的数值
     ] 
   }
   //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
 }, 
    //总开关关
   RGB_master_butten_close:function(){
    let data={
    "datastreams": [  
     {"id": "RGB_master","datapoints":[{"value": 0}]},
      //led是数据流的名称，value是要传上去的数值
     ] 
   }
   //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
 },
 //阈值补光开
 threshold_butten_open:function(){
  let data={
  "datastreams": [  
   {"id": "RGB_threshold","datapoints":[{"value": 1}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
 //阈值补光关
 threshold_butten_close:function(){
  let data={
  "datastreams": [  
   {"id": "RGB_threshold","datapoints":[{"value": 0}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
 //时间补光开
 time_butten_open:function(){
  let data={
  "datastreams": [  
   {"id": "RGB_time","datapoints":[{"value": 1}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
 //时间补光关
 time_butten_close:function(){
  let data={
  "datastreams": [  
   {"id": "RGB_time","datapoints":[{"value": 0}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
  //总开关事件
  master_switch: function (e) {
    if(e.detail.value == false){
      this.setData({
        threshold_value: false,
        time_value: false
      });
      this.RGB_master_butten_close();
      this.threshold_butten_close();
      this.time_butten_close();
    }else{
      this.RGB_master_butten_open();
    }
  },
  //阈值补光开关事件
  threshold_switch: function (e) {
    if(e.detail.value == true){
      this.setData({
        time_value: false
      })
      this.threshold_butten_open();
      this.time_butten_close();
    }
    else{
      this.threshold_butten_close();
    }
  },
  //时间补光开关事件
  time_switch: function (e) {
    if(e.detail.value == true){
      this.setData({
        threshold_value: false
      })
      this.time_butten_open();
      this.threshold_butten_close();
    }
    else{
      this.time_butten_close();
    }
  },
   //R色值
   RGB_R_value:function(R_number){
    let data={
    "datastreams": [  
     {"id": "R_value","datapoints":[{"value": R_number}]},
      //led是数据流的名称，value是要传上去的数值
     ] 
   }
   //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
 }, 
    //G色值
    RGB_G_value:function(G_number){
      let data={
      "datastreams": [  
       {"id": "G_value","datapoints":[{"value": G_number}]},
        //led是数据流的名称，value是要传上去的数值
       ] 
     }
     //按钮发送命令控制硬件
      wx.request({
        url:'https://api.heclouds.com/devices/1069586792/datapoints',
        header: {
          'content-type': 'application/json',
          'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
        },
        method: 'POST',
        data: JSON.stringify(data),//data数据转换成JSON格式
        success(res){
          console.log("成功",res.data)
        },
        fail(res){
          console.log("失败",res)
        }
      })
   }, 
    //B色值
    RGB_B_value:function(B_number){
      let data={
      "datastreams": [  
        {"id": "B_value","datapoints":[{"value": B_number}]},
        //led是数据流的名称，value是要传上去的数值
        ] 
      }
      //按钮发送命令控制硬件
      wx.request({
        url:'https://api.heclouds.com/devices/1069586792/datapoints',
        header: {
          'content-type': 'application/json',
          'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
        },
        method: 'POST',
        data: JSON.stringify(data),//data数据转换成JSON格式
        success(res){
          console.log("成功",res.data)
        },
        fail(res){
          console.log("失败",res)
        }
      })
    }, 
  //RGB调光事件
  R_value: function (e){
    this.RGB_R_value(e.detail.value);
  },
  G_value: function (e){
    this.RGB_G_value(e.detail.value);
    //console.log(e.detail.value)
  },
  B_value: function (e){
    this.RGB_B_value(e.detail.value);
    //console.log(e.detail.value)
  },
  //阈值补光值
  get_threshold_value:function(threshold_number){
    let data={
    "datastreams": [  
      {"id": "threshold_value","datapoints":[{"value": threshold_number}]},
      //led是数据流的名称，value是要传上去的数值
      ] 
    }
    //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
  }, 
  //阈值补光值事件
  threshold_value: function (e){
    this.get_threshold_value(e.detail.value);
    //console.log(e.detail.value)
  },
   //发送结束时间
   push_end_time:function(end_time){
    let data={
    "datastreams": [  
      {"id": "RGB_end_time","datapoints":[{"value": end_time}]},
      //led是数据流的名称，value是要传上去的数值
      ] 
    }
    //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
  }, 
    //发送开始时间
    push_start_time:function(start_time){
    let data={
    "datastreams": [  
      {"id": "RGB_start_time","datapoints":[{"value": start_time}]},
      //led是数据流的名称，value是要传上去的数值
      ] 
    }
    //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
  }, 

  //开始时间设置
  startTimeChange: function (e) {
    start_time_value = e.detail.value
    if(start_time_set.split(":")[0] + start_time_set.split(":")[1] > e.detail.value.split(":")[0] + e.detail.value.split(":")[1]){
      wx.showToast({
        title: '请重新设置',
        icon: 'error',
        duration: 1500//持续的时间
      })
    }else{
      this.push_start_time(e.detail.value);
      this.setData({
        start_time: e.detail.value
      });
      start_time_set = e.detail.value;
      wx.showToast({
        title: '设置成功',
        icon: 'success',
        duration: 1500//持续的时间
      });
    }
  },
  //结束时间设置
  endTimeChange: function (e) {
    if( e.detail.value.split(":")[0] + e.detail.value.split(":")[1] < start_time_value.split(":")[0] + start_time_value.split(":")[1]){
      wx.showToast({
        title: '请重新设置',
        icon: 'error',
        duration: 1500//持续的时间
      })
    }else{
      this.push_end_time(e.detail.value);
      wx.showToast({
        title: '设置成功',
        icon: 'success',
        duration: 1500//持续的时间
      });
      this.setData({
        end_time: e.detail.value
      });
      end_time_set = e.detail.value;
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const that = this;
    setInterval(function () {
      const _currentTime = util.formatTime(new Date()).split(" ")[1];
      var _hdeg = _currentTime.split(":")[0];
      var _mdeg = _currentTime.split(":")[1];
      if(start_time_set.split(":")[0] + start_time_set.split(":")[1] < _hdeg + _mdeg){
        that.setData({
          start_time: _hdeg + ':' + _mdeg,
        });
        start_time_set = _hdeg + ':' + _mdeg;
        start_time_value = start_time_set;

      }
    }, 200)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})