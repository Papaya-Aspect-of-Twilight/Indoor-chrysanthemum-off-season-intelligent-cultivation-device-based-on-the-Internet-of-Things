
var wxCharts = require("../../utils/wxcharts");
//定义记录初始屏幕宽度比例，便于初始化
var app = getApp();
//定义记录初始屏幕宽度比例，便于初始化
var windowW=0;

//创建数组
var tempertaure_array = [0,0,0,0,0,0,0,0,0,0];
var illumination_array = [0,0,0,0,0,0,0,0,0,0];
var airhumidty_array = [0,0,0,0,0,0,0,0,0,0];
var soilhumidty_array = [0,0,0,0,0,0,0,0,0,0];

var areaChart_temperature = null;
var areaChart_illumination = null;
var areaChart_airhumidity = null;
var areaChart_soilhumidity = null;

Page({

  data: {
    
  },
  
//更新数据
  updateData: function () {
    //温度数据更新
    var series_temperature = [{
        name: '温度 °C',
        data: tempertaure_array,
        color: '#4c71ff', //折线颜色
    }];
    areaChart_temperature.updateData({
        series: series_temperature
    });
    //光照数据更新
    var series_illumination = [{
      name: '光照 %',
      data: illumination_array,
      color: '#f4ea2a', //折线颜色
    }];
    areaChart_illumination.updateData({
      series: series_illumination
    });
    //空气湿度数据更新
    var series_airhumidty = [{
      name: '空气湿度 %',
      data: airhumidty_array,
      color: '#1afa29', //折线颜色
    }];
    areaChart_airhumidity.updateData({
      series: series_airhumidty
    });
    //土壤湿度数据更新
    var series_soilhumidty = [{
      name: '土壤湿度 %',
      data: soilhumidty_array,//y轴数据
      color: '#d81e06', //折线颜色
    }];
      areaChart_soilhumidity.updateData({
      series: series_soilhumidty
    });
},

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
     // 屏幕宽度
     this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth
    }) ;
    //计算屏幕宽度比列
    windowW = this.data.imageWidth;
    //更新数据
    setInterval(function () {
      tempertaure_array.push(app.globalData.tempertaure);
      illumination_array.push(app.globalData.illumination);
      airhumidty_array.push(app.globalData.airhumidty);
      soilhumidty_array.push(app.globalData.soilhumidty);
      tempertaure_array.shift();
      illumination_array.shift();
      airhumidty_array.shift();
      soilhumidty_array.shift();

      that.updateData()
    }, 100)
     //温度
     areaChart_temperature = new wxCharts({
      canvasId: 'myte_lineCanvas',
      animation: false,
      type: 'area',
      categories: ['0', '1', '2', '3', '4', '5','6', '7', '8', '9'],
      series: [{
       name: '温度 °C',
       data: tempertaure_array,//y轴数据
       color: '#4c71ff', //折线颜色
      }
      ],
      xAxis: {   //是否隐藏x轴分割线
        disableGrid: false,
      },
      yAxis: {
        min: 0,
        max: 100,
        gridColor: '#e0e6f1',
        type: 'value',
      },
      extra: {
        legendTextColor: '#000',
      },
      dataLabel: false,  //是否在图表上直接显示数据
      dataPointShape: true, //是否在图标上显示数据点标志
      width: windowW+11,
      height: 220,
     });
      //光照
      areaChart_illumination =  new wxCharts({
      canvasId: 'myill_lineCanvas',
      animation: false,
      type: 'area',
      categories: ['0', '1', '2', '3', '4', '5','6', '7', '8', '9'],
      series: [{
       name: '光照 %',
       data: illumination_array,//y轴数据
       color: '#f4ea2a', //折线颜色
      }
      ],
      xAxis: {   //是否隐藏x轴分割线
        disableGrid: false,
      },
      yAxis: {
        min: 0,
        max: 100,
        gridColor: '#e0e6f1',
        type: 'value',
      },
      extra: {
        legendTextColor: '#000',
      },
      dataLabel: false,  //是否在图表上直接显示数据
      dataPointShape: true, //是否在图标上显示数据点标志
      width: windowW+11,
      height: 220,
     });
      //空气湿度
      areaChart_airhumidity = new wxCharts({
      canvasId: 'myah_lineCanvas',
      animation: false,
      type: 'area',
      categories: ['0', '1', '2', '3', '4', '5','6', '7', '8', '9'],
      series: [{
        name: '空气湿度 %',
        data: airhumidty_array,//y轴数据
        color: '#1afa29', //折线颜色
      }
      ],
      xAxis: {   //是否隐藏x轴分割线
        disableGrid: false,
      },
      yAxis: {
        min: 0,
        max: 100,
        gridColor: '#e0e6f1',
        type: 'value',
      },
      extra: {
        legendTextColor: '#000',
      },
      dataLabel: false,  //是否在图表上直接显示数据
      dataPointShape: true, //是否在图标上显示数据点标志
      width: windowW+11,
      height: 220,
      });
    //土壤湿度
     areaChart_soilhumidity = new wxCharts({
      canvasId: 'mysh_lineCanvas',
      animation: false,
      type: 'area',
      categories: ['0', '1', '2', '3', '4', '5','6', '7', '8', '9'],
      series: [{
        name: '土壤湿度 %',
        data: soilhumidty_array,//y轴数据
        color: '#d81e06', //折线颜色
      }
      ],
      xAxis: {   //是否隐藏x轴分割线
        disableGrid: false,
      },
      yAxis: {
        min: 0,
        max: 100,
        gridColor: '#e0e6f1',
        type: 'value',
      },
      extra: {
        legendTextColor: '#000',
      },
      dataLabel: false,  //是否在图表上直接显示数据
      dataPointShape: true, //是否在图标上显示数据点标志
      width: windowW+11,
      height: 220,
      });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})