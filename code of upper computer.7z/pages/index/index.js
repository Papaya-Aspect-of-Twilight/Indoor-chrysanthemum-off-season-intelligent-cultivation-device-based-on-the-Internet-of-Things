//首先引入wxcharts.js插件
var wxCharts = require("../../utils/wxcharts");
var app = getApp();
//定义记录初始屏幕宽度比例，便于初始化
var windowW=0;
//全局变量
var tempertaure = 0;
var illumination = 0;
var airhumidty = 0;
var soilhumidty = 0;

//页面全局变量
var ringChart_temperature = null;
var ringChart_illumination = null;
var ringChart_airhumidity = null;
var ringChart_soilhumidity = null;
var button_flage = 0; 

Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    button_text : "启动上位机",
    background_color : "green"
  },

  push_wx_contral : function(value){
    let data={
    "datastreams": [  
      {"id": "wx_contral","datapoints":[{"value": value}]},
      //led是数据流的名称，value是要传上去的数值
      ] 
    }
    //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
  }, 

    /**
   * Button按钮点击事件
   */
  Button_function: function () {  
    if(button_flage == 0)
    {
      this.setData({
        button_text : "关闭上位机",
        background_color : "red"
    });
      button_flage = 1;
      this.push_wx_contral(1);//启动上位机
    }
    else
    {
      this.setData({
        button_text : "启动上位机",
        background_color : "green"
      });
      button_flage = 0;
      this.push_wx_contral(0);//关闭上位机
    }
  },

  //获取平台数据
  getinfo(){
    var that = this
    wx.request({
      url: 'https://api.heclouds.com/devices/1069586792/datastreams',
      header:{
        "api-key": "e3vMjQcEAbl73vQ8QojkrQ6K4=Q="
      },
      method:"GET",
      success: function(e){
        //console.log("获取成功",e)
        //console.log("tem=",e.data.data[0].current_value)
        tempertaure = e.data.data[0].current_value;
        illumination = e.data.data[1].current_value;
        airhumidty = e.data.data[2].current_value;
        soilhumidty = e.data.data[3].current_value;
        app.globalData.tempertaure = tempertaure;
        app.globalData.illumination = illumination;
        app.globalData.airhumidty = airhumidty;
        app.globalData.soilhumidty = soilhumidty;
        app.globalData.residue_water = e.data.data[20].current_value;//获取剩余水量
      }
    });
  },

  //更新数据
  updateData(){
    var that = this
    //温度数据更新
    var series_temperature = [{
      name: '',
      data: tempertaure,
      color: "#4c71ff",
    }, {
      name: '',
      data: 100-tempertaure,
      color: "rgba(255, 255, 255, 0.3)",
    }, ];
    ringChart_temperature.updateData({
        series: series_temperature,
        //canvasId: 'voltageCanvas'+i,
        title: {
          name: tempertaure+'°C',
        },
      });
    //光照数据更新
    var series_illumination = [{
      name: '',
      data: illumination,
      color: "#f4ea2a",
    }, {
      name: '',
      data: 100-illumination,
      color: "rgba(255, 255, 255, 0.3)",
    }, ];
    ringChart_illumination.updateData({
      series: series_illumination,
      title: {
        name: illumination+'%',
      },
    });
    //空气湿度数据更新
    var series_airhumidty = [{
      name: '',
      data: airhumidty,
      color: "#1afa29",
    }, {
      name: '',
      data: 100-airhumidty,
      color: "rgba(255, 255, 255, 0.3)",
    }, ];
    ringChart_airhumidity.updateData({
        series: series_airhumidty,
        title: {
          name: airhumidty+'%',
        },
      });
      //土壤湿度数据更新
      var series_soilhumidty = [{
        name: '',
        data: soilhumidty,
        color: "#d81e06",
      }, {
        name: '',
        data: 100-soilhumidty,
        color: "rgba(255, 255, 255, 0.3)",
      }, ];
      ringChart_soilhumidity.updateData({
          series: series_soilhumidty,
          title: {
            name: soilhumidty+'%',
          },
        });
    },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    // 屏幕宽度
    this.setData({
      imageWidth: wx.getSystemInfoSync().windowWidth
    }) ;
    console.log(this.data.imageWidth) ;
 
    //计算屏幕宽度比列
    windowW = this.data.imageWidth/375;
    console.log(windowW);
    //调用获取数据函数实时刷新
    //定时器
    setInterval(function () {
      that.getinfo()
      that.updateData()
    }, 200)
    
     
  },
  onReady: function (){
     // 温度图表
     ringChart_temperature =  new wxCharts({
      animation: false,
      canvasId: 'temperature_ringCanvas',
      type: 'ring',
      extra: {
        ringWidth: 10,
        pie: {
          offsetAngle: 270
        }
      },
      title: {
        name: tempertaure+'°C',
        color: '#7cb5ec',
        fontSize: 15
      },
      subtitle: {
        name: '温度',
        color: '#666666',
        fontSize: 15
      },
      series: [{
        name: '',
        data: tempertaure,
        color: "#4c71ff",
      }, {
        name: '',
        data: 100-tempertaure,
        color: "rgba(255, 255, 255, 0.3)",
      }, ],
      disablePieStroke: true,
      width: (190),
      height: (190),
      dataLabel: false,
      legend: false,
      padding: 0
    });
     // 光照图表
     ringChart_illumination =  new wxCharts({
      animation: false,
      canvasId: 'illumination_ringCanvas',
      type: 'ring',
      extra: {
        ringWidth: 10,
        pie: {
          offsetAngle: 270
        }
      },
      title: {
        name: illumination+'%',
        color: '#7cb5ec',
        fontSize: 15
      },
      subtitle: {
        name: '光照',
        color: '#666666',
        fontSize: 15
      },
      series: [{
        name: '',
        data: illumination,
        color: "#f4ea2a"
      }, {
        name: '',
        data: 100-illumination,
        color: "rgba(255, 255, 255, 0.3)",
      }, ],
      disablePieStroke: true,
      width: (190),
      height: (190),
      dataLabel: false,
      legend: false,
      padding: 0
    });
    // 空气湿度
      ringChart_airhumidity =  new wxCharts({
        animation: false,
      canvasId: 'airhumidity_ringCanvas',
      type: 'ring',
      extra: {
        ringWidth: 10,
        pie: {
          offsetAngle: 270
        }
      },
      title: {
        name: airhumidty+'%',
        color: '#7cb5ec',
        fontSize: 15
      },
      subtitle: {
        name: '空气湿度',
        color: '#666666',
        fontSize: 15
      },
      series: [{
        name: '',
        data: airhumidty,
        color: "#1afa29"
      }, {
        name: '',
        data: 100-airhumidty,
        color: "rgba(255, 255, 255, 0.3)",
      }, ],
      disablePieStroke: true,
      width: (190),
      height: (190),
      dataLabel: false,
      legend: false,
      padding: 0
    });
    // 土壤湿度
     ringChart_soilhumidity =  new wxCharts({
      animation: false,
      canvasId: 'soilhumidity_ringCanvas',
      type: 'ring',
      extra: {
        ringWidth: 10,
        pie: {
          offsetAngle: 270
        }
      },
      title: {
        name: soilhumidty+'%',
        color: '#7cb5ec',
        fontSize: 15
      },
      subtitle: {
        name: '土壤湿度',
        color: '#666666',
        fontSize: 15
      },
      series: [{
        name: '',
        data: soilhumidty,
        color: "#d81e06"
      }, {
        name: '',
        data: 100-soilhumidty,
        color: "rgba(255, 255, 255, 0.3)",
      }, ],
      disablePieStroke: true,
      width: (190),
      height: (190),
      dataLabel: false,
      legend: false,
      padding: 0
    });

  },
  onShow: function () {

  },
})




