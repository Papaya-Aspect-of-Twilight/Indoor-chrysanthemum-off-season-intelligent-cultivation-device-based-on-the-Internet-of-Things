var util = require( "../.././utils/util.js" );
//在page页面引入app，同时声明变量，获得所需要的全局变量
var app = getApp();

var start_time_set = '00:00';
var end_time_set = '00:00';
var start_time_value = '';
Page({
  /**
   * 页面的初始数据
   */
  //传到前端的数据
  data: {
    master_value: false,
    threshold_value: false,
    time_value: false,
    start_time: start_time_set,
    end_time: end_time_set,
    residue_value: 0
  },
   //总开关开
   pump_master_butten_open:function(){
    let data={
    "datastreams": [  
     {"id": "pump_master","datapoints":[{"value": 1}]},
      //led是数据流的名称，value是要传上去的数值
     ] 
   }
   //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
 }, 
    //总开关关
   pump_master_butten_close:function(){
    let data={
    "datastreams": [  
     {"id": "pump_master","datapoints":[{"value": 0}]},
      //led是数据流的名称，value是要传上去的数值
     ] 
   }
   //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
 },
 //阈值浇花开
 pump_threshold_butten_open:function(){
  let data={
  "datastreams": [  
   {"id": "pump_threshold","datapoints":[{"value": 1}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
 //阈值浇花关
 pump_threshold_butten_close:function(){
  let data={
  "datastreams": [  
   {"id": "pump_threshold","datapoints":[{"value": 0}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
 //时间浇花开
 pump_time_butten_open:function(){
  let data={
  "datastreams": [  
   {"id": "pump_time","datapoints":[{"value": 1}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
 //时间浇花关
 pump_time_butten_close:function(){
  let data={
  "datastreams": [  
   {"id": "pump_time","datapoints":[{"value": 0}]},
    //led是数据流的名称，value是要传上去的数值
   ] 
 }
 //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
  //总开关事件
  master_switch: function (e) {
    if(e.detail.value == false){
      this.setData({
        threshold_value: false,
        time_value: false
      })
      //总开关关，全关
      this.pump_master_butten_close()
      this.pump_threshold_butten_close()
      this.pump_time_butten_close()
    }
    else{
      this.pump_master_butten_open()
    }
  },
  //阈值浇花开关事件
  threshold_switch: function (e) {
    if(e.detail.value == true){
      this.setData({
        time_value: false
      })
      //开阈值，关时间
      this.pump_threshold_butten_open()
      this.pump_time_butten_close()
    }else{
      this.pump_threshold_butten_close()
    }
  },
  //时间浇花开关事件
  time_switch: function (e) {
    if(e.detail.value == true){
      this.setData({
        threshold_value: false
      })
      //开时间，关阈值
      this.pump_time_butten_open()
      this.pump_threshold_butten_close()
    }else{
      this.pump_time_butten_close()
    }
  },
   //水流控制值
   push_water_value:function(pump_water_value){
    let data={
    "datastreams": [  
     {"id": "pump_water_value","datapoints":[{"value": pump_water_value}]},
      //led是数据流的名称，value是要传上去的数值
     ] 
   }
   //按钮发送命令控制硬件
    wx.request({
      url:'https://api.heclouds.com/devices/1069586792/datapoints',
      header: {
        'content-type': 'application/json',
        'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
      },
      method: 'POST',
      data: JSON.stringify(data),//data数据转换成JSON格式
      success(res){
        console.log("成功",res.data)
      },
      fail(res){
        console.log("失败",res)
      }
    })
 }, 
 //水流控制事件
  water_value: function (e){
    this.push_water_value(e.detail.value);
  },
  //阈值浇花控制值
  push_threshold_water_value:function(pump_threshold_water_value){
  let data={
  "datastreams": [  
    {"id": "pump_threshold_water_value","datapoints":[{"value": pump_threshold_water_value}]},
    //led是数据流的名称，value是要传上去的数值
    ] 
  }
  //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
  //阈值浇花控制事件
  threshold_water_value: function (e){
    this.push_threshold_water_value(e.detail.value);
  },
  //发送结束时间
  push_pump_end_time:function(pump_end_time){
  let data={
  "datastreams": [  
    {"id": "pump_end_time","datapoints":[{"value": pump_end_time}]},
    //led是数据流的名称，value是要传上去的数值
    ] 
  }
  //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
  //发送开始时间
  push_pump_start_time:function(pump_start_time){
  let data={
  "datastreams": [  
    {"id": "pump_start_time","datapoints":[{"value": pump_start_time}]},
    //led是数据流的名称，value是要传上去的数值
    ] 
  }
  //按钮发送命令控制硬件
  wx.request({
    url:'https://api.heclouds.com/devices/1069586792/datapoints',
    header: {
      'content-type': 'application/json',
      'api-key':'e3vMjQcEAbl73vQ8QojkrQ6K4=Q='
    },
    method: 'POST',
    data: JSON.stringify(data),//data数据转换成JSON格式
    success(res){
      console.log("成功",res.data)
    },
    fail(res){
      console.log("失败",res)
    }
  })
}, 
  //开始时间设置
  startTimeChange: function (e) {
    start_time_value = e.detail.value
    if(start_time_set.split(":")[0] + start_time_set.split(":")[1] > e.detail.value.split(":")[0] + e.detail.value.split(":")[1]){
      wx.showToast({
        title: '请重新设置',
        icon: 'error',
        duration: 1500//持续的时间
      })
    }else{
      this.setData({
        start_time: e.detail.value
      });
      start_time_set = e.detail.value;
      wx.showToast({
        title: '设置成功',
        icon: 'success',
        duration: 1500//持续的时间
      });
      this.push_pump_start_time(e.detail.value)
    }
  },
  //结束时间设置
  endTimeChange: function (e) {
    if( e.detail.value.split(":")[0] + e.detail.value.split(":")[1] < start_time_value.split(":")[0] + start_time_value.split(":")[1]){
      wx.showToast({
        title: '请重新设置',
        icon: 'error',
        duration: 1500//持续的时间
      })
    }else{
      wx.showToast({
        title: '设置成功',
        icon: 'success',
        duration: 1500//持续的时间
      })
      this.setData({
        end_time: e.detail.value
      });
      this.push_pump_end_time(e.detail.value)
      end_time_set = e.detail.value;
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    const that = this;
    setInterval(function () {
      const _currentTime = util.formatTime(new Date()).split(" ")[1];
      var _hdeg = _currentTime.split(":")[0];
      var _mdeg = _currentTime.split(":")[1];
      if(start_time_set.split(":")[0] + start_time_set.split(":")[1] < _hdeg + _mdeg){
        that.setData({
          start_time: _hdeg + ':' + _mdeg,
          residue_value:app.globalData.residue_water,
        });
        start_time_set = _hdeg + ':' + _mdeg;
        start_time_value = start_time_set;

      }
      that.setData({
        residue_value:app.globalData.residue_water,
      });
    }, 200)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})